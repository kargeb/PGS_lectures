

export const sqr = (x) => x*x;

