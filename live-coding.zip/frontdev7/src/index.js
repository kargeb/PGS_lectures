
import {sqr} from './math';

console.log(sqr(5));







